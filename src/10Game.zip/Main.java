import javalib.worldimages.*; // images, like RectangleImage or OverlayImages
import javalib.funworld.*; // the abstract World class and the big-bang library
import java.awt.Color;
import java.util.Random;

interface IGamePiece {

  // World constants
  int SCREEN_HEIGHT = 300; // in pixels
  int SCREEN_WIDTH = 500; // in pixels
  double TICK_RATE = 1.0 / 28.0;
  Color FONT_COLOR = Color.BLACK;
  int FONT_SIZE = 13;
  // Bullet constants
  int INITIAL_BULLET_RADIUS = 4; // in pixels
  int MAXIMUM_BULLET_RADIUS = 10; // in pixels
  Color BULLET_COLOR = Color.PINK;
  int BULLET_SPEED = 8; // pixels per tick
  // Ship constants
  int SHIP_RADIUS = 20;
  Color SHIP_COLOR = Color.CYAN;
  int SHIP_SPEED = 4;

  // METHODS:
  // determines whether a GamePiece is offscreen
  boolean isOffScreen();

  // moves a game piece
  IGamePiece move();

  // draws a game piece
  WorldScene draw(WorldScene acc);
}

abstract class AGamePiece implements IGamePiece {
  int xPos;
  int yPos;
  int radius;

  public AGamePiece(int xPos, int yPos, int radius) {
    this.xPos = xPos;
    this.yPos = yPos;
    this.radius = radius;
  }
  /*
   * TEMPLATE AGamePiece:
   * 
   * Fields: this.xPos -- int this.yPos -- int
   * 
   * Methods:
   * 
   * this.isOffScreen() -- boolean
   *
   */

  public boolean isOffScreen() {
    return this.xPos > SCREEN_WIDTH || this.xPos < 0 || this.yPos > SCREEN_HEIGHT || this.yPos < 0;
  }

}

class Utils {
  private static final int MAXIMUM_BULLET_RADIUS = 50;

  /*
   * TEMPLATE Utils: Template might not be necessary Methods:
   * 
   * this.initializeShip(int n) -- Ship
   * 
   */
  // spawns new ships randomly along the Y-axis on the left and right side on the
  // screen and moves them through the screen
  Ship intiallizeShip(int n) {
    if (n == 0) {
      return new Ship(0, 15 + new Random().nextInt(275), 4, 10, Color.CYAN, OutlineMode.SOLID);
    }
    return new Ship(500, 15 + new Random().nextInt(275), -4, 10, Color.CYAN, OutlineMode.SOLID);
  }

  // creates a list of bullets containing only new exploded bullets with an
  // increasing radius and number of bullets per hit and a changing angle
  ILoBullets createsExplodedBullets(int x, int y, int timesHit, int count, double angle) {
    if (count == 0) {
      return new MtLoBullets();
    }
    else {
      double newangle = angle * count;
      double newradian = Math.toRadians(newangle);

      return new ConsLoBullet(
          new Bullet(x, y, 8, this.radiusRegulator(timesHit), Color.PINK, OutlineMode.SOLID,
              timesHit, Math.cos(newradian) * 8, Math.sin(newradian) * 8),
          this.createsExplodedBullets(x, y, timesHit, count - 1, angle));

    }
  }

  // to ensure the size of the bullet never exceeds the maximum bullet radius
  int radiusRegulator(int timesHit) {
    if (5 * timesHit > MAXIMUM_BULLET_RADIUS) {
      return MAXIMUM_BULLET_RADIUS;
    }
    else {
      return 5 * timesHit;
    }
  }
}