import tester.*; // The tester library
import javalib.worldimages.*; // images, like RectangleImage or OverlayImages
import javalib.funworld.*; // the abstract World class and the big-bang library
import java.awt.Color;
import java.util.Random;

// represents the World  
class MyWorld extends World {
  int numBullets; // the number of bullets avaiable to shoot
  ILoBullets bullets;
  ILoShips ships;// the list of gamepieces represented in the world
  int count;
  int shipshit;

  public MyWorld(int numBullets, ILoBullets bullets, ILoShips ships, int count, int shipshit) {
    this.numBullets = numBullets;
    this.bullets = bullets;
    this.ships = ships;
    this.count = count;
    this.shipshit = shipshit;
  }
  /*
   * TEMPLATE MyWorld:
   * 
   * Fields: this.numBullets -- int this.gamepieces -- ILoGamePiece this.count --
   * int
   * 
   * Methods:
   * 
   * this.makeScene() -- WorldScene this.onTick() -- World this.onKeyEvent(String)
   * -- World
   * 
   * Methods on fields:
   * 
   * this.gamepieces.draw(WordlScene) -- WorldScene this.gamepieces.moveAll() --
   * ILoGamePiece
   */

  //creates the WorldScene
  public WorldScene makeScene() {
    return this.bullets
        .draw(this.ships.draw(new WorldScene(500, 300).placeImageXY(this.scoreBoard(), 50, 260)));
  }

  public WorldScene makeFinalScene() {
    return new WorldScene(500, 300).placeImageXY(this.scoreBoard(), 50, 260)
        .placeImageXY(gameOverText(), 250, 150);
  }

  // creates the score board image with bullets and ships hit
  public WorldImage scoreBoard() {
    return new AboveImage(this.bulletsLeftText(), this.shipsHitText());
  }

  // return the game over text
  public WorldImage gameOverText() {
    return new TextImage("Game Over", 40, Color.BLACK);
  }

  // return the Image of the amount of bullets left to shoot
  public WorldImage bulletsLeftText() {
    return new TextImage("Bullets left: " + Integer.toString(this.numBullets), 15, Color.BLACK);
  }

  // return the Image of the amount of ships that have been hit
  public WorldImage shipsHitText() {
    return new TextImage("Ships hit: " + Integer.toString(this.shipshit), 15, Color.BLACK);
  }

  // counts the number of hit ships in the world
  public int countShipsW() {
    return this.shipshit + this.ships.countShips(this.bullets);
  }

  // moves the world on tick
  public World onTick() {
    if (this.numBullets == 0) {
      return new MyWorld(this.numBullets,
          this.bullets.removeOffscreen().createExplodedBullets(ships).moveBullets(),
          this.ships.removeOffscreen().removeShips(this.bullets).moveShips(), this.count,
          this.countShipsW());
    }
    else {
      return this.handleWorld();
    }
  }

  public World handleWorld() {

    if (this.count == 28) {
      return new MyWorld(this.numBullets,
          this.bullets.removeOffscreen().createExplodedBullets(ships).moveBullets(),
          new ConsLoShips(new Utils().intiallizeShip(new Random().nextInt(2)), this.ships)
              .removeOffscreen().removeShips(this.bullets).moveShips(),
          0, this.countShipsW());
    }
    else {
      return new MyWorld(this.numBullets,
          this.bullets.removeOffscreen().createExplodedBullets(ships).moveBullets(),
          this.ships.removeOffscreen().removeShips(this.bullets).moveShips(), this.count + 1,
          this.countShipsW());
    }

  }

  // handles the world on key press
  // when "space" is pressed a bullet gets shot
  public World onKeyEvent(String key) {
    if (key.equals(" ") && this.numBullets > 0) {
      return new MyWorld(this.numBullets - 1,
          new ConsLoBullet(new Bullet(250, 300, 8, 5, Color.PINK, OutlineMode.SOLID, 1, 0, 8),
              this.bullets),
          this.ships, this.count, this.shipshit);
    }
    else {
      return new MyWorld(this.numBullets, this.bullets, this.ships, this.count, this.shipshit);
    }
  }

  public boolean isEnd() {
    return this.numBullets == 0 && this.ships.isEnd();
  }

  public WorldEnd worldEnds() {
    if (this.isEnd()) {
      return new WorldEnd(true, this.makeFinalScene());
    }
    else {
      return new WorldEnd(false, this.makeScene());
    }
  }
}

class ExamplesMyWorldProgram {

  boolean testBigBang(Tester t) {
    MyWorld w = new MyWorld(10, new MtLoBullets(), new MtLoShips(), 0, 0);
    int worldWidth = 500;
    int worldHeight = 300;
    double tickRate = 1 / 28.0;
    return w.bigBang(worldWidth, worldHeight, tickRate);
  }
  // EXAMPLES:

  Ship ship1 = new Ship(250, 100, 4, 10, Color.CYAN, OutlineMode.SOLID); // should be hit
  Ship ship2 = new Ship(240, 100, 4, 10, Color.CYAN, OutlineMode.SOLID); // should be hit
  Ship ship3 = new Ship(140, 230, 4, 10, Color.CYAN, OutlineMode.SOLID); // should not be hit
  Ship ship4 = new Ship(300, 150, 4, 10, Color.CYAN, OutlineMode.SOLID); // not hit
  // OffScreen Ships

  Bullet bullet1 = new Bullet(250, 100, 10);
  Bullet bullet2 = new Bullet(130, 100, 10);
  Bullet bullet3 = new Bullet(420, 100, 10);
  Bullet bullet4 = new Bullet(140, 230, 10);
  // OffScreen Bullets
  Bullet bulletOffScreen = new Bullet(600, 600, 10);
  Bullet bulletOffScreen2 = new Bullet(610, 600, 10);

  ILoShips loships0 = new MtLoShips();
  ILoShips loships1 = new ConsLoShips(this.ship1, this.loships0); 
  ILoShips loships2 = new ConsLoShips(this.ship2, this.loships1); 
  ILoShips loships3 = new ConsLoShips(this.ship3, this.loships2); 
  ILoShips loships4 = new ConsLoShips(this.ship4, this.loships3);

  ILoBullets lobullet0 = new MtLoBullets();
  ILoBullets lobullet1 = new ConsLoBullet(this.bullet1, this.lobullet0); 
  ILoBullets lobullet2 = new ConsLoBullet(this.bullet2, this.lobullet1);
  ILoBullets lobulletcb = new ConsLoBullet(this.bullet1, this.lobullet2); 
  ILoBullets lobullet3 = new ConsLoBullet(this.bullet4, this.lobulletcb); 
  ILoBullets lobullet4 = new ConsLoBullet(this.bullet3, this.lobullet3); 

  // ILoBullet List for testing OffScreen
  ILoBullets lobulletOffS1 = new ConsLoBullet(this.bulletOffScreen, this.lobullet2);
  ILoBullets lobulletsOffS2 = new ConsLoBullet(this.bulletOffScreen2, this.lobulletOffS1);

  // TESTS:

  // Tests method isHit from ConsLoShips be
  boolean testIsHitShip(Tester t) {
    return t.checkExpect(this.bullet1.isHitShip(this.ship1), true)
        && t.checkExpect(this.bullet1.isHitShip(this.ship2), true);
  }

  boolean testIsHit(Tester t) {
    return t.checkExpect(this.loships2.isHit(this.bullet1), true)
        && t.checkExpect(this.loships2.isHit(this.bullet2), false);
  }

  boolean testCountShips(Tester t) {
    return t.checkExpect(this.loships0.countShips(this.lobullet0), 0)
        && t.checkExpect(this.loships2.countShips(this.lobullet1), 2)
        && t.checkExpect(this.loships1.countShips(this.lobullet1), 1)
        && t.checkExpect(this.loships3.countShips(this.lobullet1), 2)
        && t.checkExpect(this.loships4.countShips(this.lobullet4), 3);
  }

  boolean testRemoveShips(Tester t) {
    return t.checkExpect(this.loships2.removeShips(this.lobullet2), this.loships0) && t.checkExpect(
        this.loships3.removeShips(this.lobullet2), new ConsLoShips(this.ship3, this.loships0));
  }

  boolean testRemoveOffScreen(Tester t) {
    return t.checkExpect(this.lobullet0.removeOffscreen(), this.lobullet0)
        && t.checkExpect(this.lobulletOffS1.removeOffscreen(), this.lobullet2)
        && t.checkExpect(this.lobulletsOffS2.removeOffscreen(), this.lobullet2);
  }

  boolean testAppend(Tester t) {
    return t.checkExpect(this.lobullet1.append(this.lobullet2), this.lobulletcb);
  }
}
